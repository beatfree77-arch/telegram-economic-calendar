# Telegram Economic Calendar Bot

A small Python bot that posts Forex Factory economic-calendar reminders to
`@trading_journal_alert`. It checks the eight major currencies (USD, EUR, GBP,
JPY, AUD, NZD, CAD, CHF) and sends one alert near 15 minutes and one near
5 minutes before each scheduled event. The message includes the currency,
event, impact, UTC event time, forecast, previous value, and a clickable source
attribution.

## Data source and limitations

The bot reads Forex Factory's public weekly JSON feed:
<https://nfs.faireconomy.media/ff_calendar_thisweek.json>. Forex Factory links
calendar downloads from its calendar page:
<https://www.forexfactory.com/calendar>.

This is a free public feed, not a key-based official API or a feed with a
published service-level guarantee. It can be unavailable, change format, or
provide incomplete fields; missing forecast and previous values are displayed
as “Not available.” The bot rejects event times without an explicit timezone
offset rather than guessing. Each alert links to the Forex Factory calendar.
The feed was reachable during this project's verification, but that does not
guarantee future availability.

## Free scheduled hosting with GitHub Actions

The included workflow runs as a scheduled job every five minutes. It is not a
continuously running process. GitHub Actions schedules are best-effort: jobs
can start late or be skipped during high load, and the five-minute polling
interval means 15- and 5-minute reminders are approximate. This is not suitable
when exact delivery timing is required. In a public repository, scheduled jobs
may also be disabled after 60 days without repository activity.

GitHub documents standard hosted runners as free for public repositories:
<https://docs.github.com/en/billing/managing-billing-for-github-actions>.
Its schedule documentation describes possible queue delays, skipped runs, and
the default-branch requirement:
<https://docs.github.com/en/actions/reference/events-that-trigger-workflows#schedule>.

The workflow commits a small alert-deduplication state file back to the
repository after each run. It needs repository `contents: write` permission.
Only hashed event identifiers and send timestamps are stored there; no Telegram
token is written to the repository.

### One-time setup

1. Create a Telegram bot with [@BotFather](https://t.me/BotFather) and copy its
   token. Do not put the token in source code or commit it.
2. Add the bot to `@trading_journal_alert` as an administrator with permission
   to post messages.
3. Put this project in a **public GitHub repository** so scheduled hosted
   runners can be used without paid hosting. Keep the workflow file on the
   repository's default branch.
4. In GitHub, open **Settings → Secrets and variables → Actions → New
   repository secret**. Name the secret `TELEGRAM_BOT_TOKEN` and paste the
   BotFather token into the secret field.
5. Under **Settings → Actions → General → Workflow permissions**, allow
   read/write access to repository contents. The workflow uses this permission
   to preserve deduplication state between scheduled runs.
6. Optional: add an Actions repository variable named `TELEGRAM_CHANNEL` if you
   want a destination other than `@trading_journal_alert`.
7. In the repository's **Actions** tab, enable the workflow if prompted.
8. To verify Telegram delivery, open **Actions → Telegram economic calendar
   alerts → Run workflow**, select the `send_test_message` checkbox, and run
   it on the default branch. The bot posts a clearly labeled test message to
   the channel without reading the calendar or changing duplicate-prevention
   state. Confirm it appears in `@trading_journal_alert`; the workflow log also
   reports whether Telegram accepted the message. Leave the box unchecked for
   a normal manual run, which only sends alerts due at that time.

### Uploading the files from Android

1. Download the project ZIP attached with these instructions and extract it
   with the phone's Files app. The ZIP is a convenience archive; GitHub Actions
   needs the files extracted into the repository, not the ZIP uploaded as one
   file.
2. Open `github.com` in your browser, sign in, tap **+ → New repository**, give
   it a name such as `trading-journal-alerts`, select **Public**, and create
   the repository.
3. From the new repository, use **Add file → Create new file**. Enter each
   exact file path below, paste the matching file contents, then tap
   **Commit changes**. GitHub creates the folders from the path. Repeat until
   each file is present:
   - `telegram-economic-calendar-bot/bot.py`
   - `telegram-economic-calendar-bot/requirements.txt`
   - `telegram-economic-calendar-bot/README.md`
   - `telegram-economic-calendar-bot/tests/test_bot.py`
   - `telegram-economic-calendar-bot/state/sent_alerts.json`
   - `telegram-economic-calendar-bot/.gitignore`
   - `.github/workflows/telegram-calendar-alerts.yml`

If the mobile browser offers **Upload files** and preserves folder paths from
the extracted archive, that is also fine. Verify the paths above in GitHub
before enabling Actions.

GitHub's workflow scheduler only runs workflows present on the default branch.
Review the Actions run history periodically, since schedule delays, feed errors,
permission problems, and Telegram delivery errors are reported there.

## Local setup and use

Python 3.10 or later is required. The bot uses only the Python standard library,
so no package installation is needed. `requirements.txt` is included to make
that dependency-free setup explicit.

```sh
export TELEGRAM_BOT_TOKEN="your-bot-token"
# Optional; defaults to @trading_journal_alert
export TELEGRAM_CHANNEL="@trading_journal_alert"
python telegram-economic-calendar-bot/bot.py --dry-run
```

`--dry-run` downloads and checks the current calendar, prints any currently due
messages, and does not send alerts or change state. A normal run sends alerts
only when it falls within the alert windows:

```sh
python telegram-economic-calendar-bot/bot.py
```

To post a clearly labeled delivery check when running locally, set the token
environment variable and use:

```sh
python telegram-economic-calendar-bot/bot.py --test-message
```

The test message is a real public post to the configured channel; it does not
represent an economic event and does not change alert state.

Running the script once is not continuous monitoring. For local automation,
schedule it externally every five minutes and keep the state file at
`telegram-economic-calendar-bot/state/sent_alerts.json`. Do not run multiple
independent schedulers against the same channel and state file.

## Tests

```sh
python -m unittest discover -s telegram-economic-calendar-bot/tests -v
```

## Reliability and duplicate handling

The bot retries temporary calendar-feed errors, handles Telegram/network
failures without printing the bot token, and stores successful alert keys so
later scheduled runs do not send the same 15- or 5-minute reminder again. The
GitHub workflow serializes scheduled runs and commits that state after a run.
As with any remote send API, an interruption after Telegram accepts a message
but before the updated state is committed can leave the outcome uncertain; the
Bot API does not provide an idempotency key for `sendMessage`.
